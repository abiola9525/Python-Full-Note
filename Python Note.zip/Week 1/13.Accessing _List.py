'''
Access Items
List items are indexed and you can access them by referring to the index number:

Example
Print the second item of the list:
'''
mylist = ["car", "table", "book"]
#print(mylist[0])
#Note: The first item has index 0.

print("")

'''
Negative Indexing
Negative indexing means start from the end

-1 refers to the last item, -2 refers to the second last item etc.

Example
Print the last item of the list:
'''
mylist = ["car", "table", "book"]
#print(mylist[-3])

print("")
'''
Range of Indexes
You can specify a range of indexes by specifying where to start and where to end the range.

When specifying a range, the return value will be a new list with the specified items.

Example
Return the third, fourth, and fifth item:
'''
mylist = ["car", "table", "book", "floor", "mice", "washer", "pen"]
#print(mylist[2:5])

# Note: The search will start at index 2 (included) and end at index 5 (not included).

# Remember that the first item has index 0.

print("")
'''
By leaving out the start value, the range will start at the first item:

Example
This example returns the items from the beginning to, but NOT including, "kiwi":
'''
mylist = ["car", "table", "book", "floor", "mice", "washer", "pen"]
#print(mylist[:4])

print("")
# By leaving out the end value, the range will go on to the end of the list:

# Example:  This example returns the items from "cherry" to the end:

mylist = ["car", "table", "book", "floor", "mice", "washer", "pen"]
#print(mylist[2:])

print("")
'''
Range of Negative Indexes
Specify negative indexes if you want to start the search from the end of the list:

Example
This example returns the items from "orange" (-4) to, but NOT including "mango" (-1):

'''
mylist = ["car", "table", "book", "floor", "mice", "washer", "pen"]
#print(mylist[-4:-1])




'''
Check if Item Exists
To determine if a specified item is present in a list use the in keyword:

Example
Check if "apple" is present in the list:
'''
thislist = ["apple", "banana", "cherry"]
if "kiwi" in thislist:
  print("Yes, 'apple' is in the fruits list")
else:
  print("Not available")
