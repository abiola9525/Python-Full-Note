# String is sequence of Unicode characters.
# We can use single quotes or double quotes to represent strings.
# Multi-line strings can be denoted using triple quotes, ''' or """.



s = "This is a string"
print(s)
s = """A multiline
string
Hello
World"""
print(s)

#   String are Array
# We can use a square bracket to access elements of the string.

a = "Welcome Home"
print(a[-6])

  # Looping Through a String
#
a = "Welcome Home"
for line in a:
     print(line)

# Length

# We use the len() function to know the lenght of a string

a = "Welcome home!"
print(len(a))

# Checking String
comment = "Python is an intresting Language!"
print("intresting" in comment)
print("like" in comment)
#
#
