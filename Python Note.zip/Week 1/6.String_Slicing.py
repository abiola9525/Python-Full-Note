# To access a range of characters in the String, the method of slicing is used. Slicing in a String is done by using a Slicing operator (colon).

#Creating a String

name = "PlatformLead"
print(name)

print(name[4:])
print(name[3:-2])
print(name[2:7])
print(name[-4:])
